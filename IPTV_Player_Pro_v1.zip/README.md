# IPTV Player Pro

iPhone ve Android için Flutter IPTV Player başlangıç uygulaması.

## Dahil
- Modern koyu arayüz
- Ana sayfa
- Canlı TV ve kategori filtreleri
- Kanal arama
- Favoriler
- M3U playlist parser
- Xtream Codes ile canlı kanal alma
- Network video playback
- Ayarlar ekranı
- Yerel playlist saklama

## Çalıştırma

1. Flutter SDK kurulu bir bilgisayarda:
   `flutter pub get`
2. Android:
   `flutter run`
3. iOS (macOS + Xcode gerekir):
   `flutter run`

Uygulama herhangi bir kanal listesini içermez. Kullanıcının kendi M3U/Xtream erişim bilgileriyle çalışacak şekilde hazırlanmıştır.

## Sonraki sürüm için
- EPG/XMLTV
- Film ve dizi katalogları
- Poster/banner tasarımı
- Çoklu profil/PIN
- Chromecast/AirPlay
- Altyazı ve ses parçası seçimi
- Android TV kumanda desteği
- iOS/Android uygulama ikonları ve mağaza paketleri
