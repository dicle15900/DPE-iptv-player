import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const IPTVApp());

class IPTVApp extends StatelessWidget {
  const IPTVApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'IPTV Player Pro',
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF06111F),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1687FF),
          brightness: Brightness.dark,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF0D2033),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class Channel {
  final String name, url, group, logo;
  bool favorite;
  Channel({
    required this.name,
    required this.url,
    this.group = 'Genel',
    this.logo = '',
    this.favorite = false,
  });
}

class XtreamService {
  static Future<List<Channel>> load({
    required String server,
    required String username,
    required String password,
  }) async {
    final base = server.replaceAll(RegExp(r'/$'), '');
    final uri = Uri.parse(
      '$base/player_api.php?username=${Uri.encodeQueryComponent(username)}&password=${Uri.encodeQueryComponent(password)}',
    );
    final response = await http.get(uri).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw Exception('Sunucu HTTP ${response.statusCode}');
    }
    final data = jsonDecode(response.body);
    if (data is! Map) throw Exception('Geçersiz Xtream yanıtı');

    final raw = await http.get(Uri.parse(
      '$base/player_api.php?username=${Uri.encodeQueryComponent(username)}&password=${Uri.encodeQueryComponent(password)}&action=get_live_streams',
    )).timeout(const Duration(seconds: 15));
    if (raw.statusCode != 200) throw Exception('Kanallar alınamadı');

    final list = jsonDecode(raw.body);
    if (list is! List) throw Exception('Kanal listesi geçersiz');

    return list.map<Channel>((e) {
      final map = Map<String, dynamic>.from(e);
      final streamId = map['stream_id'];
      final ext = (map['container_extension'] ?? 'ts').toString();
      return Channel(
        name: (map['name'] ?? 'Kanal').toString(),
        group: (map['category_name'] ?? 'Genel').toString(),
        logo: (map['stream_icon'] ?? '').toString(),
        url: '$base/live/$username/$password/$streamId.$ext',
      );
    }).toList();
  }
}

class M3UParser {
  static List<Channel> parse(String text) {
    final lines = const LineSplitter().convert(text);
    final result = <Channel>[];
    String name = '', group = 'Genel', logo = '';
    for (final raw in lines) {
      final line = raw.trim();
      if (line.startsWith('#EXTINF')) {
        final comma = line.indexOf(',');
        name = comma >= 0 ? line.substring(comma + 1).trim() : 'Kanal';
        final g = RegExp(r'group-title="([^"]*)"').firstMatch(line);
        final l = RegExp(r'tvg-logo="([^"]*)"').firstMatch(line);
        group = g?.group(1)?.trim().isNotEmpty == true ? g!.group(1)!.trim() : 'Genel';
        logo = l?.group(1) ?? '';
      } else if (line.isNotEmpty && !line.startsWith('#')) {
        result.add(Channel(name: name.isEmpty ? 'Kanal' : name, url: line, group: group, logo: logo));
        name = '';
        logo = '';
      }
    }
    return result;
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  final List<Channel> channels = [];
  String selectedGroup = 'Tümü';
  String search = '';
  final searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final p = await SharedPreferences.getInstance();
    final saved = p.getString('m3u_text');
    if (saved != null && saved.isNotEmpty) {
      setState(() => channels.addAll(M3UParser.parse(saved)));
    }
  }

  List<Channel> get filtered {
    return channels.where((c) {
      final groupOk = selectedGroup == 'Tümü' || c.group == selectedGroup;
      final searchOk = search.isEmpty || c.name.toLowerCase().contains(search.toLowerCase());
      return groupOk && searchOk;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [_home(), _channelsPage(), _favoritesPage(), _settings()];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        backgroundColor: const Color(0xFF081726),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.live_tv_outlined), selectedIcon: Icon(Icons.live_tv), label: 'Canlı TV'),
          NavigationDestination(icon: Icon(Icons.star_border), selectedIcon: Icon(Icons.star), label: 'Favoriler'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Ayarlar'),
        ],
      ),
    );
  }

  Widget _header() => Padding(
    padding: const EdgeInsets.fromLTRB(18, 16, 18, 8),
    child: Row(children: [
      const Icon(Icons.play_circle_fill, color: Color(0xFF1687FF), size: 36),
      const SizedBox(width: 10),
      const Text('IPTV Player', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const Spacer(),
      IconButton(icon: const Icon(Icons.search), onPressed: () => setState(() => tab = 1)),
    ]),
  );

  Widget _home() => CustomScrollView(slivers: [
    SliverToBoxAdapter(child: _header()),
    SliverPadding(
      padding: const EdgeInsets.all(18),
      sliver: SliverToBoxAdapter(child: _hero()),
    ),
    SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      sliver: SliverToBoxAdapter(child: _quickActions()),
    ),
    SliverPadding(
      padding: const EdgeInsets.fromLTRB(18, 24, 18, 10),
      sliver: SliverToBoxAdapter(child: Text('Kanallar', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
    ),
    if (channels.isEmpty)
      const SliverToBoxAdapter(child: _EmptyState())
    else
      SliverList.builder(
        itemCount: channels.take(8).length,
        itemBuilder: (_, i) => _channelTile(channels[i]),
      ),
  ]);

  Widget _hero() => Container(
    height: 210,
    padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(24),
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF123D68), Color(0xFF071321)],
      ),
    ),
    child: Stack(children: [
      Positioned(right: -10, top: -35, child: Icon(Icons.live_tv, size: 190, color: Colors.white.withOpacity(.06))),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Spacer(),
        const Text('Canlı TV', style: TextStyle(color: Color(0xFF62B4FF), fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Tüm yayınların\ntek uygulamada', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: () => setState(() => tab = 1),
          icon: const Icon(Icons.play_arrow),
          label: const Text('İzlemeye Başla'),
        ),
      ]),
    ]),
  );

  Widget _quickActions() {
    final items = [
      ('Canlı TV', Icons.tv, 1),
      ('Favoriler', Icons.star, 2),
      ('Sunucu Ekle', Icons.add_link, 3),
    ];
    return Row(children: items.map((e) => Expanded(
      child: Padding(
        padding: const EdgeInsets.only(right: 8),
        child: Card(
          color: const Color(0xFF0B1C2E),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => setState(() => tab = e.$3),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Column(children: [Icon(e.$2, color: const Color(0xFF1687FF)), const SizedBox(height: 7), Text(e.$1, textAlign: TextAlign.center)]),
            ),
          ),
        ),
      ),
    )).toList());
  }

  Widget _channelsPage() => Column(children: [
    _header(),
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: TextField(
        controller: searchController,
        onChanged: (v) => setState(() => search = v),
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Kanal ara...'),
      ),
    ),
    const SizedBox(height: 10),
    SizedBox(
      height: 46,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 18),
        children: ['Tümü', ...{...channels.map((e) => e.group)}].map((g) => Padding(
          padding: const EdgeInsets.only(right: 8),
          child: ChoiceChip(label: Text(g), selected: selectedGroup == g, onSelected: (_) => setState(() => selectedGroup = g)),
        )).toList(),
      ),
    ),
    Expanded(
      child: filtered.isEmpty ? const _EmptyState() : ListView.builder(itemCount: filtered.length, itemBuilder: (_, i) => _channelTile(filtered[i])),
    ),
  ]);

  Widget _favoritesPage() {
    final favs = channels.where((c) => c.favorite).toList();
    return Column(children: [
      _header(),
      Expanded(child: favs.isEmpty ? const _EmptyState(text: 'Henüz favori kanal yok') : ListView(children: favs.map(_channelTile).toList())),
    ]);
  }

  Widget _settings() => ListView(padding: const EdgeInsets.all(18), children: [
    const SizedBox(height: 8),
    const Text('Ayarlar', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
    const SizedBox(height: 18),
    _setting(Icons.add_link, 'M3U Playlist', 'M3U URL veya dosya metni ekle', _showM3U),
    _setting(Icons.dns, 'Xtream Codes', 'Sunucu + kullanıcı adı + şifre', _showXtream),
    _setting(Icons.language, 'Dil', 'Türkçe', () {}),
    _setting(Icons.dark_mode, 'Tema', 'Koyu tema', () {}),
    _setting(Icons.info_outline, 'Hakkında', 'IPTV Player Pro 1.0', () {}),
  ]);

  Widget _setting(IconData icon, String title, String sub, VoidCallback tap) => Card(
    color: const Color(0xFF0B1C2E),
    child: ListTile(
      leading: Icon(icon, color: const Color(0xFF1687FF)),
      title: Text(title),
      subtitle: Text(sub),
      trailing: const Icon(Icons.chevron_right),
      onTap: tap,
    ),
  );

  Widget _channelTile(Channel c) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 3),
    leading: _logo(c),
    title: Text(c.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
    subtitle: Text(c.group, maxLines: 1, overflow: TextOverflow.ellipsis),
    trailing: IconButton(
      icon: Icon(c.favorite ? Icons.star : Icons.star_border, color: c.favorite ? Colors.amber : null),
      onPressed: () async {
        setState(() => c.favorite = !c.favorite);
        final p = await SharedPreferences.getInstance();
        await p.setStringList('favorites', channels.where((x) => x.favorite).map((x) => x.name).toList());
      },
    ),
    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(channel: c))),
  );

  Widget _logo(Channel c) => CircleAvatar(
    radius: 25,
    backgroundColor: const Color(0xFF10273C),
    backgroundImage: c.logo.isNotEmpty ? NetworkImage(c.logo) : null,
    child: c.logo.isEmpty ? Text(c.name.isNotEmpty ? c.name.substring(0, 1).toUpperCase() : '?') : null,
  );

  Future<void> _showM3U() async {
    final controller = TextEditingController();
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('M3U Playlist'),
      content: TextField(controller: controller, maxLines: 8, decoration: const InputDecoration(hintText: 'M3U metnini buraya yapıştır...')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
        FilledButton(onPressed: () async {
          final parsed = M3UParser.parse(controller.text);
          final p = await SharedPreferences.getInstance();
          await p.setString('m3u_text', controller.text);
          setState(() { channels.clear(); channels.addAll(parsed); });
          if (mounted) Navigator.pop(context);
        }, child: const Text('Yükle')),
      ],
    ));
  }

  Future<void> _showXtream() async {
    final server = TextEditingController();
    final user = TextEditingController();
    final pass = TextEditingController();
    await showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Xtream Codes'),
      content: SingleChildScrollView(child: Column(children: [
        TextField(controller: server, decoration: const InputDecoration(labelText: 'Sunucu URL')),
        const SizedBox(height: 10),
        TextField(controller: user, decoration: const InputDecoration(labelText: 'Kullanıcı adı')),
        const SizedBox(height: 10),
        TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'Şifre')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('İptal')),
        FilledButton(onPressed: () async {
          Navigator.pop(context);
          try {
            final loaded = await XtreamService.load(server: server.text.trim(), username: user.text.trim(), password: pass.text);
            setState(() { channels.clear(); channels.addAll(loaded); });
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${loaded.length} kanal yüklendi')));
          } catch (e) {
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Hata: $e')));
          }
        }, child: const Text('Bağlan')),
      ],
    ));
  }
}

class _EmptyState extends StatelessWidget {
  final String text;
  const _EmptyState({this.text = 'Henüz kanal eklenmedi'});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(40),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.live_tv_outlined, size: 64, color: Colors.white.withOpacity(.25)),
        const SizedBox(height: 14),
        Text(text, style: const TextStyle(color: Colors.white70)),
      ]),
    ),
  );
}

class PlayerScreen extends StatefulWidget {
  final Channel channel;
  const PlayerScreen({super.key, required this.channel});
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  VideoPlayerController? controller;
  String? error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final c = VideoPlayerController.networkUrl(Uri.parse(widget.channel.url));
      await c.initialize();
      await c.play();
      setState(() => controller = c);
    } catch (e) {
      setState(() => error = 'Yayın açılamadı: $e');
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = controller;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: Text(widget.channel.name)),
      body: Center(
        child: error != null
          ? Padding(padding: const EdgeInsets.all(24), child: Text(error!, textAlign: TextAlign.center))
          : c == null
            ? const CircularProgressIndicator()
            : AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)),
      ),
      floatingActionButton: c == null ? null : FloatingActionButton(
        onPressed: () => setState(() => c.value.isPlaying ? c.pause() : c.play()),
        child: Icon(c.value.isPlaying ? Icons.pause : Icons.play_arrow),
      ),
    );
  }
}
